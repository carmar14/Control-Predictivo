x00=[0.9649;1.996];
x=x00;
for ii=1:100
    temp=Ad*x(:,ii)+Bd*(-K*(x(:,ii)-xs)+us);
    x=[x temp];
end
