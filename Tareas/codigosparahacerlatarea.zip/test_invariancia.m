x00=[0.5379;0.8895];
x=x00;
for ii=1:100
    temp=(Ad-Bd*K)*x(:,ii);
    x=[x temp];
end
